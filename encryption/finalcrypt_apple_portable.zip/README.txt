To quick start the FinalCrypt Graphical User Interface open a terminal and type:

nohup ./finalcrypt.sh &

# ===================================================================================

To start the FinalCrypt Graphical User Interface open a terminal and type:

FinalCryptPortable/bin/java -jar FinalCryptPortable/finalcrypt.jar

# ===================================================================================

To start the FinalCrypt Command Line Interface open a terminal and type:

FinalCryptPortable/bin/java -cp FinalCryptPortable/finalcrypt.jar rdj.CLUI

# ===================================================================================

Update Info

If there's a new update and you already downloaded the entire "finalcrypt_platform_portable.zip" package then downloading the finalcrypt.jar file (4MB) and replace the one in your extracted portable package is sufficient to update.

finalcrypt_apple_portable/FinalCryptPortable/finalcrypt.jar

Support: support@finalcrypt.org
