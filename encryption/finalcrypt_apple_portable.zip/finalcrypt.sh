#!/bin/sh
FinalCryptPortable/bin/java -jar FinalCryptPortable/finalcrypt.jar
