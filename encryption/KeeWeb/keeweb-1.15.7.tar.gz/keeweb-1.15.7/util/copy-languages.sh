#!/bin/sh

cp ../keeweb-plugins/docs/translations/de-DE/de-DE.json app/scripts/locales/de-DE.json
cp ../keeweb-plugins/docs/translations/fr-FR/fr-FR.json app/scripts/locales/fr-FR.json
