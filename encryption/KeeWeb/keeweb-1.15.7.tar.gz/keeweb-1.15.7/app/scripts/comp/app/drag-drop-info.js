const DragDropInfo = {
    dragObject: null
};

export { DragDropInfo };
