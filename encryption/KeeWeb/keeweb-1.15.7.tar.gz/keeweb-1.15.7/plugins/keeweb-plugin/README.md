# KeeWeb Plugin Utility

This is a plugin creation utility for [KeeWeb](https://keeweb.info).

Plugin docs: https://github.com/keeweb/keeweb/wiki/Plugins
