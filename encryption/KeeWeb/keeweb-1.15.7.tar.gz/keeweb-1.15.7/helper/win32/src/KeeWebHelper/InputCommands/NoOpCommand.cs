﻿namespace KeeWebHelper.InputCommands
{
    class NoOpCommand : InputCommandBase
    {
        public override void Execute()
        {
        }
    }
}
