package com.artifex.mupdf.fitz;

public interface SeekableInputOutputStream extends SeekableOutputStream, SeekableInputStream
{
}
